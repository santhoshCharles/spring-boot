package com.udaan.interview;

/**
 * TODO - Make other 2 classes extend this
 */
public class GetBalanceBaseModel {
}
