package com.udaan.interview;

public class GetBalanceErrorResponseModel {
    public GetBalanceErrorResponseModel() {
    }

    public Integer giveErrorCode() {
        throw new RuntimeException("Not implemented yet");
    }
}
